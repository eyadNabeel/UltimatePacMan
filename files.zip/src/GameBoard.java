import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.*;

@SuppressWarnings("serial")
public class GameBoard extends JFrame{
	
	MenuPanel defaultPanel;
	GamePanel game;
	ImagePanel instructions;
	ScorePanel highScores;
	PacManBoard mainBoard = new PacManBoard();
	JPanel currentPanel;
	private Timer myTimer;
	private int mode;
	int time = 0;
		
	public GameBoard () {
		setLocation(1920/2 - 480, 0);
		defaultPanel = new MenuPanel("pacManData/mainMenu.png");
		game = new GamePanel("pacManData/mainMap990.png");
		instructions = new ImagePanel("pacManData/instructions.png");
		highScores = new ScorePanel("pacManData/highScores.png");
		init();
	}
	
	public void init() {
		mode = 0;
		setVisible(true);
		initializePanel();
		currentPanel = game;
		defaultPanel.requestFocus();
		myTimer = new Timer(1000/20, timer);
		myTimer.start();
		setResizable(false);
	}
	
	public void initializePanel(){
		add(defaultPanel);
		pack();
	}

	public void resetBoard(){
		
		}
	
	ActionListener timer = new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent theEvent){
			time++;
			if (defaultPanel.off && mode == 0){
				defaultPanel.setVisible(false);
				if(defaultPanel.phase == 0){
					mode = 1;
					game = new GamePanel("pacManData/MainMap990.png");
					remove(defaultPanel);
					add(game);
					game.requestFocus();
				} else if(defaultPanel.phase == 1){
					mode = 1;
					game = new GamePanel("pacManData/MainMap990.png");
					game.ghostMode = true;
					remove(defaultPanel);
					add(game);
					game.requestFocus();
				} else if (defaultPanel.phase == 2){
					mode = 3;
					add(instructions);
					instructions.requestFocus();
				} else if (defaultPanel.phase == 3){
					mode = 4;
					add(highScores);
					highScores.requestFocus();
				}
			} else if(game.off && mode == 1){
				mode = 0;
				defaultPanel.off = false;
				game.setVisible(false);
				remove(game);
				defaultPanel = new MenuPanel("pacManData/MainMenu.png");
				add(defaultPanel);
				defaultPanel.setVisible(true);
				defaultPanel.requestFocus();
			} else if(instructions.off && mode == 3){
				mode = 0;
				defaultPanel.off = false;
				instructions.setVisible(false);
				remove(instructions);
				defaultPanel = new MenuPanel("pacManData/MainMenu.png");
				add(defaultPanel);
				defaultPanel.setVisible(true);
				defaultPanel.requestFocus();
				instructions = new ImagePanel("pacManData/instructions.png");
			} else if(highScores.off && mode == 4){
				mode = 0;
				defaultPanel.off = false;
				highScores.setVisible(false);
				remove(highScores);
				defaultPanel = new MenuPanel("pacManData/MainMenu.png");
				add(defaultPanel);
				defaultPanel.setVisible(true);
				defaultPanel.requestFocus();
				highScores = new ScorePanel("pacManData/highScores.png");
			} 
//			else if(game.off && mode == 2){
//				mode = 0;
//				defaultPanel.off = false;
//				game.setVisible(false);
//				remove(game);
//				defaultPanel = new MenuPanel("pacManData/MainMenu.png");
//				add(defaultPanel);
//				defaultPanel.setVisible(true);
//				defaultPanel.requestFocus();
//			}
		}
	};
	
	}
