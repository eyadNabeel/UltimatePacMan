import java.awt.Point;


public class PacMan extends AnimateObject{
	
	private int phase;
	private int prePhase;
	
	private String [] phaseRightFilePaths = {"pacManData/pacManPhase/fullPacMan.png", 
											 "pacManData/pacManPhase/pacManRight.png",
											 "pacManData/pacManPhase/pacManRight1.png", 
											 "pacManData/pacManPhase/pacManRight2.png",
											 "pacManData/pacManPhase/pacManRight3.png",
											 "pacManData/pacManPhase/emptyPacMan.png"};
	
	private String [] phaseLeftFilePaths = {"pacManData/pacManPhase/fullPacMan.png", 
											"pacManData/pacManPhase/pacManLeft.png",
										    "pacManData/pacManPhase/pacManLeft1.png", 
										    "pacManData/pacManPhase/pacManLeft2.png",
										    "pacManData/pacManPhase/pacManLeft3.png",
										    "pacManData/pacManPhase/emptyPacMan.png"};
	
	private String [] phaseUpFilePaths = {"pacManData/pacManPhase/fullPacMan.png", 
									      "pacManData/pacManPhase/pacManUp.png",
									      "pacManData/pacManPhase/pacManUp1.png", 
										  "pacManData/pacManPhase/pacManUp2.png",
									      "pacManData/pacManPhase/pacManUp3.png",
									      "pacManData/pacManPhase/emptyPacMan.png"};
	
	private String [] phaseDownFilePaths = {"pacManData/pacManPhase/fullPacMan.png", 
			 							 	"pacManData/pacManPhase/pacManDown.png",
					 					    "pacManData/pacManPhase/pacManDown1.png", 
					 					    "pacManData/pacManPhase/pacManDown2.png",
					 					    "pacManData/pacManPhase/pacManDown3.png",
											"pacManData/pacManPhase/emptyPacMan.png"};
	
	public PacMan(){
		this.setLocation(new Point (15 * (960/30), 17 * (990/31)));
		phase = 0;
		orientation = 0;
	}
	
	@Override
	public String currentImage(){
		if (orientation == 0){
			return phaseRightFilePaths[phase];
		} else if (orientation == 1){
			return phaseUpFilePaths[phase];
		} else if (orientation == 2){
			return phaseLeftFilePaths[phase];
		} else if (orientation == 3){
			return phaseDownFilePaths[phase];
		} else {
			throw new IllegalArgumentException("Invalid Orientation");
		}
	}
	
@Override
	public void oscillate(){
		if (phase == 0){
			phase = 1;
			prePhase = 0;
		} else if (phase == 1){
			if (prePhase == 2){
				phase = 0;
			} else if (prePhase == 0){
				phase = 2;
			} else {
				throw new IllegalArgumentException("Invalid Phase");
			}
			prePhase = 1;
		} else if (phase == 2){
			phase = 1;
			prePhase = 2;
		} else {
			throw new IllegalArgumentException("Invalid Phase");
		}
	}

	public int getPhase(){
		return phase;
	}
	
	public void wane(){
		if (phase < 5){
			phase++;
		} else if (phase == 5){
		} else {
			throw new IllegalArgumentException("Invalid Phase");
		}
	}
	
	public void reset(){
		this.setLocation(new Point (15 * (960/30), 17 * (990/31)));
		prePhase = 0;
		phase = 0;
		orientation = 0;
	}
	
}
