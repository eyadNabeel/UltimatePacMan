import java.awt.Point;


public class AnimateObject implements GameObjectApi{
	
	private Point location;
	int orientation;
	
	public AnimateObject(){
		
	}
	
	public void oscillate(){
		
	}
	
	public Point getLocation(){
		return location;
	}
	
	public void setLocation(Point p){
		location = p;
	}
	
	public void setLocation(int x, int y){
		location = new Point(x, y);
	}
	
	public void moveUp(int d){
		int x = (int)location.x;
		int y = (int)location.y;
		y = y - d;
		if (y < 0){
			y = 0;
		}
		location = new Point(x, y);
		oscillate();
	}
	
	public void moveDown(int d){
		int x = (int)location.x;
		int y = (int)location.y;
		y = y + d;
		if (y > 990){
			y = 990;
		}
		location = new Point(x, y);
		oscillate();
	}
	
	public void moveLeft(int d){
		int x = (int)location.x;
		int y = (int)location.y;
		x = x-d;
		if(x < -45){
			x = -45;
		}
		location = new Point(x, y);
		oscillate();
	}
	
	public void moveRight(int d){
		int x = (int)location.x;
		int y = (int)location.y;
		x = x+d;
		if(x > 960){
			x = 960;
		}
		location = new Point(x, y);
		oscillate();
	}
	
	public void move(){
		if (orientation == 0){
			this.moveRight();
		} else if (orientation == 1){
			this.moveUp();
		} else if (orientation == 2){
			this.moveLeft();
		} else if (orientation == 3){
			this.moveDown();
		}
	}
	public void moveUp(){
		int x = (int)location.x;
		int y = (int)location.y;
		y--;
		if (y < 0){
			y = 0;
		}
		location = new Point(x, y);
		oscillate();
	}
	
	public void moveDown(){
		int x = (int)location.x;
		int y = (int)location.y;
		y++;
		if (y > 990){
			y = 990;
		}
		location = new Point(x, y);
		oscillate();
	}
	
	public void moveLeft(){
		int x = (int)location.x;
		int y = (int)location.y;
		x--;
		if(x < -45){
			x = -45;
		}
		location = new Point(x, y);
		oscillate();
	}
	
	public void moveRight(){
		int x = (int)location.x;
		int y = (int)location.y;
		x++;
		if(x > 960){
			x = 960;
		}
		location = new Point(x, y);
		oscillate();
	}
	
	public void move(int distance){
		if (orientation == 0){
			this.moveRight(distance);
		} else if (orientation == 1){
			this.moveUp(distance);
		} else if (orientation == 2){
			this.moveLeft(distance);
		} else if (orientation == 3){
			this.moveDown(distance);
		}
	}
	
	public void setOrientation(int o){
		orientation = o;
	}
	
	public String currentImage(){
		return null;
	}

}
