import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.LinkedList;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;


public class ScorePanel extends JPanel{

	private int gameWidth = 960;
	private int gameLength = 990;
	private String imagePath;
	private Timer myTimer;
	private Ghost iconG;
	private PacMan iconP;
	public boolean off;
	KeyListener menuControl = new KeyListener(){
		@Override
		public void keyPressed(KeyEvent arg0) {
			if(arg0.getKeyCode() == KeyEvent.VK_ESCAPE){
				off = true;
			}
		}
		@Override
		public void keyReleased(KeyEvent arg0) {
		}
		@Override
		public void keyTyped(KeyEvent arg0) {
		}};
	
	public ScorePanel(String imagePath){
		iconG = new Ghost();
		iconP = new PacMan();
		off = false;
		this.imagePath = imagePath;
		myTimer = new Timer(1000/20, menuTimer);
		myTimer.start();
		setPreferredSize(new Dimension (gameWidth, gameLength));
		addKeyListener(menuControl);
		setVisible(true);
	}
	
	public void drawBackground (Graphics g){
		BufferedImage img;
		try {
			img = ImageIO.read(new File(imagePath));
		} catch (IOException e) {
			e.printStackTrace();
			img = null;
		}
		g.drawImage(img, 0, 0, null);
	}
	
	public void drawScores(String filePath, Graphics g, int x, int y){
		Font pixelFont = null;
		try {
			pixelFont = Font.createFont(Font.TRUETYPE_FONT, new File("pacManData/pixelFont2.ttf")).deriveFont(25f);
		} catch (FontFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		FileLineIterator scanner = new FileLineIterator(filePath);
		LinkedList<String> scores = new LinkedList<String>();
		while (scanner.hasNext()){
			scores.add(scanner.next());
		}
		g.setFont(pixelFont);
		g.setColor(new Color (255, 151, 3));
		for (int i = 0; i < scores.size(); i += 2){
			g.drawString(scores.get(i), x, y + (50 * i));
			g.drawString(scores.get(i + 1), x + 180, y + (50 * i));
		}
	}
	
	public void drawAnimateObject (AnimateObject o, Graphics g, int x, int y){
		BufferedImage object;
		try {
			object = ImageIO.read(new File(o.currentImage()));
		} catch (IOException e) {
			e.printStackTrace();
			object = null;
		} catch (IllegalArgumentException e){
			object = null;
		}
		g.drawImage(object, x, y, 45, 45, null);
		o.oscillate();
	}
	
	public void paintComponent(Graphics g){
		drawBackground(g);
		drawScores("pacManData/highScores.txt", g, 40, 360);
		drawScores("pacManData/highScoresGhost.txt", g, 520, 360);
		drawAnimateObject(iconP, g, 415, 230);
		drawAnimateObject(iconG, g, 520, 230);
		setFocusable(true);
	}
	
	ActionListener menuTimer = new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent theEvent){
			repaint();
		}
	};
	
}
