import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.*;

public class GamePanel extends JPanel{
	
	private final int gameLength = 990;
	private final int gameWidth = 960;
	private int myTimerDelay;
	private Timer myTimer;
	private final int frameRate = 20;
	private String imagePath;
	private PacMan myPacMan = new PacMan();
	private Random rand = new Random();
	private int phaseCounter = 0;
	private PacManBoard gameBoard = new PacManBoard();
	private boolean deadMan = false;
	public boolean off = false;
	public boolean ghostMode = false;
	int time = 0;
	int score = 0;
	private int lives = 3;
	private LinkedList<Point> beadList = new LinkedList<Point>();
	Font pacFont = null;
	Font pixelFont = null;
	KeyListener pacManControl = new KeyListener(){
		@Override
		public void keyPressed(KeyEvent arg0) {
			// TODO Auto-generated method stub
			if(arg0.getKeyCode() == KeyEvent.VK_ESCAPE){
				off = true;
			}
			myPacMan.setOrientation(pacManOrientation(arg0));
		}
		@Override
		public void keyReleased(KeyEvent arg0) {
		}
		@Override
		public void keyTyped(KeyEvent arg0) {
		}};
	Ghost[] ghosts = {new Ghost(465, 350, 0), new Ghost(530, 447, 1),
			  new Ghost(465, 447, 2), new Ghost(400, 447, 3)};	
	public GamePanel(String bgImage){
		try {
			pacFont = Font.createFont(Font.TRUETYPE_FONT, new File("pacManData/pacFont.ttf")).deriveFont(30f);
		} catch (FontFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pixelFont = Font.createFont(Font.TRUETYPE_FONT, new File("pacManData/pixelFont.ttf")).deriveFont(25f);
		} catch (FontFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		initializeBeads();
		imagePath = bgImage;
		setPreferredSize(new Dimension (gameWidth, gameLength));
		setVisible(true);
		myTimerDelay = 1000/frameRate;
		myTimer = new Timer(myTimerDelay, gameTimer);
		myTimer.start();
		addKeyListener(pacManControl);
		setFocusable(true);
	}	
	void initializeBeads(){
		Cell[][] boardArray = gameBoard.getBoard();
		for (int i = 0; i < boardArray.length; i++){
			for (int j = 0; j < boardArray[i].length; j++){
				if (boardArray[i][j].getType() == CellType.SPACE){
					if (!(j >= 12 && j <= 17 && i >= 13 && i <= 15)){
						beadList.add(new Point(j, i));
					}
				}
			}
		}
		convertToGridSystem(beadList);
	}	
	public void convertToGridSystem(LinkedList<Point> ls){
		for (Point p : ls){
			p.x = p.x * (960/29);
			p.y = (int)((p.y + 0.5) * (990/31));
		}
	}	
	public void drawBeads(Graphics g){
		BufferedImage object;
		try {
			object = ImageIO.read(new File("pacManData/beads.png"));
		} catch (IOException e) {
			e.printStackTrace();
			object = null;
		}
		for(Point p : beadList){
			g.drawImage(object, p.x, p.y, 10, 10, null);
		}
	}	
	public void checkPacManEatingBeads(){
		Point p = myPacMan.getLocation();
		Point container = null;
		for(Point pn : beadList){
			if (pn.x <= p.x + 40 && pn.x >= p.x  && pn.y <= p.y + 40 && pn.y >= p.y){
				container = pn;
				break;
			}
		}
		if (container != null){
			beadList.remove(container);
			score++;
		}
	}	
	public void ghostOrientationController (Ghost g, int speed, boolean obstacle){
		if(obstacle){
			LinkedList<Integer> orientations = new LinkedList<Integer>();
			orientations.add(0);
			orientations.add(1);
			orientations.add(2);
			orientations.add(3);
			int orientation = rand.nextInt(4);
			g.setOrientation(orientations.get(orientation));
			if(!checkObstacles(g, speed)){
				orientations.remove(orientation);
				orientation = rand.nextInt(3);
				g.setOrientation(orientations.get(orientation));
			}
		} else {
			if (myPacMan.getLocation().x < g.getLocation().x - 45){
				g.setOrientation(2);
			} else if (myPacMan.getLocation().x > g.getLocation().x + 45){
				g.setOrientation(0);
			} else if (myPacMan.getLocation().y < g.getLocation().y){
				g.setOrientation(1);
			} else if (myPacMan.getLocation().y > g.getLocation().y){
				g.setOrientation(3);
			}
		}
	}	
	public void drawAnimateObject (AnimateObject o, Graphics g, int dx, int dy, int speed, boolean movement){
		BufferedImage object;
		try {
			object = ImageIO.read(new File(o.currentImage()));
		} catch (IOException e) {
			e.printStackTrace();
			object = null;
		} catch (IllegalArgumentException e){
			object = null;
		}
		g.drawImage(object, o.getLocation().x, o.getLocation().y, dx, dy, null);
		if (checkObstacles(o, speed) && movement){
			o.move(speed);
		} 
	}	
	public boolean checkObstacles (AnimateObject o, int speed){
		Point location = o.getLocation();
		if(o != myPacMan && ghostMode){
			return true;
		} else {
		int x = (location.x);
		int y = location.y;
		if (o.orientation == 0){
			x += speed;
			x += 20;
		} else if (o.orientation == 1){
			y -= speed;
		} else if (o.orientation == 2){
			x -= speed;
		} else if (o.orientation == 3){
			y += speed;
			y += 20;
		}
		x = (int)(x/(960/28.0) + 1.5);
		y = (int)(y/(990/31));
		CellType target;
		try{
			target = gameBoard.getValue(x, y).getType();
		} catch (ArrayIndexOutOfBoundsException e){
			e.printStackTrace();
			target = CellType.WALL;
		}
		if(target == CellType.SPACE || (target == CellType.GATE && o instanceof Ghost)){
			return true;
		} else if (target == CellType.PORTAL){
			o.move(-960);
			return true;
		} else {
			return false;
		}
		}
	}	
	public void drawBackground (Graphics g){
		BufferedImage img;
		try {
			img = ImageIO.read(new File(imagePath));
		} catch (IOException e) {
			e.printStackTrace();
			img = null;
		}
		g.drawImage(img, 0, 0, null);
	}	
	public void drawLitUp (Graphics g){
		BufferedImage img;
		try {
			img = ImageIO.read(new File("pacManData/litUp990.png"));
		} catch (IOException e) {
			e.printStackTrace();
			img = null;
		}
		g.drawImage(img, 0, 0, null);
	}	
	public int pacManOrientation(KeyEvent e){
		int key = e.getKeyCode();
		int orientation = myPacMan.orientation;
		if(key == KeyEvent.VK_RIGHT){
			orientation = 0;
		} else if(key == KeyEvent.VK_UP){
			orientation = 1;
		} else if(key == KeyEvent.VK_LEFT){
			orientation = 2;
		} else if(key == KeyEvent.VK_DOWN){
			orientation = 3;
		}
		return orientation;
	}	
	public void resetBoard(){
		initializeBeads();
		resetCharacters();
		myTimer.setDelay(1000/frameRate);
	}
	
	public void resetCharacters(){
		myPacMan.reset();
		for (Ghost g : ghosts){
			g.reset();
		}
	}	
	public void drawLives(int lives, Graphics g){
		BufferedImage object;
		PacMan tempPacMan = new PacMan();
		tempPacMan.oscillate();
		try {
			object = ImageIO.read(new File(tempPacMan.currentImage()));
		} catch (IOException e) {
			e.printStackTrace();
			object = null;
		} catch (IllegalArgumentException e){
			object = null;
		}
		for (int i = 0; i < lives; i++){
			g.drawImage(object, 5 + (55 * i), 340, 45, 45, null);
		}
	}	
	public void printScores(Graphics g, int x, int y){
		g.drawString("Score   " + score, x, y);
	}	
	public boolean pacManDead(){
		Point p = myPacMan.getLocation();
		for (Ghost g : ghosts){
			Point pg = g.getLocation();
			if (p.x <= pg.x + 30 && p.x + 30 >= pg.x && p.y <= pg.y + 30 && p.y + 30 >= pg.y){
				lives --;
				return true;
			}
		}
		return false;
	}
	
	public void writeStringsToFile(List<String> stringsToWrite, String filePath, boolean append) {
		File file = Paths.get(filePath).toFile();
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter (file, append));
			for (String s : stringsToWrite){
				writer.write(s);
				writer.newLine();
			}
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("IOException Caught");
		}
		
	}	
	public void highScores (){
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm");
		Date date = new Date();
		String currentDate = dateFormat.format(date);
		String mode;
		String filePath;
		if(ghostMode){
			mode = "Ghost Mode";
			filePath = "pacManData/highScoresGhost.txt";
		} else {
			mode = "Classic";
			filePath = "pacManData/highScores.txt";
		}
		FileLineIterator scanner = new FileLineIterator(filePath);
		LinkedList<String> scoreList = new LinkedList<String>();
		LinkedList<String> dateList = new LinkedList<String>();
		LinkedList<String> modeList = new LinkedList<String>();
		for (int i = 0; i < 10; i++){
			if (scanner.hasNext()){
				if (i % 2 == 0){
					scoreList.add(scanner.next());
				} else {
					dateList.add(scanner.next());
				}
			}
		}
		
		scanner.quit();	
		boolean highScore = false;
		String highScoreIndex = "";
		for(String s : scoreList){
			if(score > Integer.parseInt(s)){
				highScore = true;
				highScoreIndex = s;
				break;
			}
		}
		if(highScore){
			int index = scoreList.indexOf(highScoreIndex);
			scoreList.add(index, Integer.toString(score));
			dateList.add(index, currentDate);
			scoreList.removeLast();
		}
		LinkedList<String> finalList = new LinkedList<String>();
		for(int i = 0; i < scoreList.size(); i++){
			finalList.add(scoreList.get(i));
			finalList.add(dateList.get(i));
		}
		writeStringsToFile(finalList, filePath, false);
	}
	@Override
	public void paintComponent(Graphics g){
		time++;
		if (!deadMan && lives > 0 && !beadList.isEmpty()){
			myTimer.setDelay(1000/frameRate);
			super.paintComponent(g);
			checkPacManEatingBeads();
			drawBackground(g);
			drawBeads(g);
			drawLives(lives, g);
			g.setFont(pixelFont);
			g.setColor(new Color(255, 151, 3));
			printScores(g, 820, 365);
			int pacSpeed;
			if(ghostMode){
				pacSpeed = 8;
			} else {
				pacSpeed = 6;
			}
			for (Ghost gh : ghosts){
				if (phaseCounter % 20 == 0 || !checkObstacles(gh, 6)){
					if (ghostMode){
						ghostOrientationController(gh, 6, false);
					} else {
						ghostOrientationController(gh, 6, true);
					}
				}
				drawAnimateObject(gh, g, 45, 45, 6, true);
			}
			drawAnimateObject(myPacMan, g, 45, 45, pacSpeed, true);
			phaseCounter++;
			deadMan = pacManDead();
		} else if (beadList.isEmpty()){
			if (myTimer.getDelay() < 150){
				myTimer.setDelay(1500);
			} else {
				initializeBeads();
				resetBoard();
				drawLitUp(g);
			}
		} else if (lives >= 0){
			if(myPacMan.getPhase() == 5){
				if(lives != 0){
					deadMan = false;
					resetCharacters();
				} else {
					lives = -1;
					time = 0;
				}
			} else if (myTimer.getDelay() < 150){
					myTimer.setDelay(1500);
			} else {
				myTimer.setDelay(150);
				drawBackground(g);
				for (Ghost gh : ghosts){
					drawAnimateObject(gh, g, 45, 45, 0, false);
				}
				drawAnimateObject(myPacMan, g, 45, 45, 0, false);
				myPacMan.wane();				
			}
		} else {
			if(time == 1){
				highScores();
			}
			drawBackground(g);
			g.setColor(new Color(255, 151, 3));
			g.setFont(pacFont);
			g.drawString("Game Over", 385, 390);
			g.setFont(pixelFont);
			g.setColor(new Color(255, 151, 3));
			printScores(g, 430, 470);
			if(time == 30){
				off = true;
			}
		}
	}
	
	public void redraw(){
		this.repaint();
	}
	
	ActionListener gameTimer = new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent theEvent){
			redraw();
		}
	};
	
}
