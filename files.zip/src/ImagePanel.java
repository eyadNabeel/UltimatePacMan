import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;


public class ImagePanel extends JPanel{
	
	private int gameWidth = 960;
	private int gameLength = 990;
	private String imagePath;
	public boolean off;
	KeyListener menuControl = new KeyListener(){
		@Override
		public void keyPressed(KeyEvent arg0) {
			if(arg0.getKeyCode() == KeyEvent.VK_ESCAPE){
				off = true;
			}
		}
		@Override
		public void keyReleased(KeyEvent arg0) {
		}
		@Override
		public void keyTyped(KeyEvent arg0) {
		}};
	
	public ImagePanel(String imagePath){
		off = false;
		this.imagePath = imagePath;
		setPreferredSize(new Dimension (gameWidth, gameLength));
		addKeyListener(menuControl);
		setVisible(true);
	}
	
	public void drawBackground (Graphics g){
		BufferedImage img;
		try {
			img = ImageIO.read(new File(imagePath));
		} catch (IOException e) {
			e.printStackTrace();
			img = null;
		}
		g.drawImage(img, 0, 0, null);
	}
	
	public void paintComponent(Graphics g){
		drawBackground(g);
		setFocusable(true);
	}
}
