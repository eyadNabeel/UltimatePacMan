import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;


public class MenuPanel extends JPanel{

	private final int gameLength = 990;
	private final int gameWidth = 960; 
	private int myTimerDelay;
	private Timer myTimer;
	private final int frameRate = 20;
	private String filePath;
	public int phase = 0;
	public boolean off = false;
	private Ghost pointer = new Ghost(200, 200);
	private PacMan mover = new PacMan();
	KeyListener menuControl = new KeyListener(){
		@Override
		public void keyPressed(KeyEvent arg0) {
			if(arg0.getKeyCode() == KeyEvent.VK_DOWN && phase < 3){
				phase += 1;
			} else if (arg0.getKeyCode() == KeyEvent.VK_UP && phase > 0){
				phase -= 1;
			}
			if(arg0.getKeyCode() == KeyEvent.VK_ENTER){
				off = true;
			}
		}
		@Override
		public void keyReleased(KeyEvent arg0) {
		}
		@Override
		public void keyTyped(KeyEvent arg0) {
		}};
	
	public MenuPanel (String filePath){
		mover.setLocation(0, 230);
		this.filePath = filePath; 
		setPreferredSize(new Dimension (gameWidth, gameLength));
		setVisible(true);
		myTimerDelay = 1000/frameRate;
		myTimer = new Timer(myTimerDelay, menuTimer);
		myTimer.start();
		addKeyListener(menuControl);
		setFocusable(true);
	}
	
	public void drawBackground (Graphics g){
		BufferedImage img;
		try {
			img = ImageIO.read(new File(filePath));
		} catch (IOException e) {
			e.printStackTrace();
			img = null;
		}
		g.drawImage(img, 0, 0, null);
	}
	
	public void drawAnimateObject (AnimateObject o, Graphics g, boolean move){
		BufferedImage object;
		try {
			object = ImageIO.read(new File(o.currentImage()));
		} catch (IOException e) {
			e.printStackTrace();
			object = null;
		} catch (IllegalArgumentException e){
			object = null;
		}
		if(!move){
			if (phase == 0){
				o.setLocation(230, 360);
			} else if (phase == 1){
				o.setLocation(200, 535);
			} else if (phase == 2){
				o.setLocation(185, 693);
			} else if (phase == 3){
				o.setLocation(185, 850);
			}
		}
		g.drawImage(object, o.getLocation().x, o.getLocation().y, null);
		if(move){
			o.move(10);
			if(o.getLocation().x == 960){
				o.setLocation(-55, o.getLocation().y);
			}
		} else {
			o.oscillate();
		}
	}
	
	public void paintComponent(Graphics g){
		drawBackground(g);
		drawAnimateObject(pointer, g, false);
		drawAnimateObject(mover, g, true);
	}
	
	ActionListener menuTimer = new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent theEvent){
			repaint();
		}
	};
	
}
