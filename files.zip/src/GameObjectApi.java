import java.awt.Point;


public interface GameObjectApi {

	Point getLocation();
	
	void setLocation(int x, int y);
	
	void setLocation(Point loc);
		
}
	