import java.awt.Point;
import java.util.Random;

public class Ghost extends AnimateObject{

	private int phase;
	private final int color;
	private Random rand = new Random();
	private final Point initLocation;
	
	private final String [] phaseRightFilePaths = {"pacManData/ghostPhase/redGhostRight0.png", 
											 "pacManData/ghostPhase/redGhostRight1.png", 
											 "pacManData/ghostPhase/blueGhostRight0.png", 
											 "pacManData/ghostPhase/blueGhostRight1.png",
											 "pacManData/ghostPhase/orangeGhostRight0.png", 
											 "pacManData/ghostPhase/orangeGhostRight1.png",
											 "pacManData/ghostPhase/pinkGhostRight0.png", 
											 "pacManData/ghostPhase/pinkGhostRight1.png"};
	
	private final String [] phaseLeftFilePaths = {"pacManData/ghostPhase/redGhostLeft0.png", 
											   "pacManData/ghostPhase/redGhostLeft1.png",
											   "pacManData/ghostPhase/blueGhostLeft0.png", 
											   "pacManData/ghostPhase/blueGhostLeft1.png",
											   "pacManData/ghostPhase/orangeGhostLeft0.png", 
											   "pacManData/ghostPhase/orangeGhostLeft1.png",
											   "pacManData/ghostPhase/pinkGhostLeft0.png", 
											   "pacManData/ghostPhase/pinkGhostLeft1.png"};
	
	private final String [] phaseUpFilePaths = {"pacManData/ghostPhase/redGhostUp0.png", 
											 "pacManData/ghostPhase/redGhostUp1.png",
											 "pacManData/ghostPhase/blueGhostUp0.png", 
											 "pacManData/ghostPhase/blueGhostUp1.png",
											 "pacManData/ghostPhase/orangeGhostUp0.png", 
											 "pacManData/ghostPhase/orangeGhostUp1.png",
											 "pacManData/ghostPhase/pinkGhostUp0.png", 
											 "pacManData/ghostPhase/pinkGhostUp1.png"};
	
	private final String [] phaseDownFilePaths = {"pacManData/ghostPhase/redGhostDown0.png", 
											"pacManData/ghostPhase/redGhostDown1.png",
											"pacManData/ghostPhase/blueGhostDown0.png", 
										    "pacManData/ghostPhase/blueGhostDown1.png",
										    "pacManData/ghostPhase/orangeGhostDown0.png", 
										    "pacManData/ghostPhase/orangeGhostDown1.png",
										    "pacManData/ghostPhase/pinkGhostDown0.png", 
											"pacManData/ghostPhase/pinkGhostDown1.png"};
				
	
	public Ghost(Point loc, int color){
		phase = 0;
		orientation = 0;
		if (color <= 3){
			this.color = color;
		} else {
			throw new IllegalArgumentException("Invalid Color Code");
		}
		initLocation = loc;
		this.setLocation(loc);
	}
	
	public Ghost(int x, int y, int color){
		phase = 0;
		orientation = 0;
		if (color <= 3){
			this.color = color;
		} else {
			throw new IllegalArgumentException("Invalid Color Code");
		}
		initLocation = new Point(x, y);
		this.setLocation(x, y);
	}
	
	public Ghost(Point loc){
		phase = 0;
		orientation = 0;
		color = rand.nextInt(4);
		initLocation = loc;
		this.setLocation(loc);
	}
	
	public Ghost(int x, int y){
		phase = 0;
		orientation = 0;
		color = rand.nextInt(4);
		initLocation = new Point(x, y);
		this.setLocation(x, y);
	}
	
	public Ghost(int color){
		phase = 0;
		orientation = 0;
		if (color <= 3){
			this.color = color;
		} else {
			throw new IllegalArgumentException("Invalid Color Code");
		}
		initLocation = new Point(rand.nextInt(6) + 12, rand.nextInt(3) + 13);
		this.setLocation(initLocation);
	}
	
	public Ghost(){
		phase = 0;
		orientation = 0;
		color = rand.nextInt(4);
		initLocation = new Point(rand.nextInt(6) + 12, rand.nextInt(3) + 13);
		this.setLocation(initLocation);
	}
	
	@Override
	public String currentImage(){
		 if (orientation == 0){
			return phaseRightFilePaths[(color * 2) + phase];
		} else if (orientation == 1){
			return phaseUpFilePaths[(color * 2) + phase];
		} else if (orientation == 2){
			return phaseLeftFilePaths[(color * 2) + phase];
		} else if (orientation == 3){
			return phaseDownFilePaths[(color * 2) + phase];
		} else {
			throw new IllegalArgumentException("Invalid Orientation");
		}
	}
	
@Override
	public void oscillate(){
		if (phase == 0){
			phase = 1;
		} else if (phase == 1){
			phase = 0;
		} else {
			throw new IllegalArgumentException("Invalid Phase");
		}
	}	
	
	public void reset (){
		phase = 0;
		orientation = 0;
		this.setLocation(initLocation);
	}
	
}
