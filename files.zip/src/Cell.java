
public class Cell {

	private CellType type;
	
	public Cell (int type){
		if (type == 0){
			this.type = CellType.SPACE;
		} else if (type == 1){
			this.type = CellType.WALL;
		} else if (type == 2){
			this.type = CellType.PORTAL;
		} else if (type == 3){
			this.type = CellType.GATE;
		} else {
			throw new IllegalArgumentException("Invalid Type Code");
		}
	}
	
	public CellType getType(){
		return type;
	}
	
	public char toChar(){
		if (type == CellType.GATE){
			return 'G';
		} else if (type == CellType.PORTAL){
			return 'P';
		} else if (type == CellType.SPACE){
			return ' ';
		}  else{
			return '|';
		}
	}
}
