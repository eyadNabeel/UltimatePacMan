
public class Game {

	public static void main(String[] args) {
		GameBoard board = new GameBoard();
		board.init();
	}

}
