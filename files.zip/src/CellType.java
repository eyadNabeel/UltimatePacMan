
public enum CellType {

	SPACE,
	
	WALL,
	
	GATE,
	
	PORTAL;
	
}
